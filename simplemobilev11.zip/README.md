Modified version of [simplemobile](https://github.com/Handyfon/simplemobile) by Handyfon. Work in progress.
Needs modified version of [Argon Combat HUD](https://github.com/JustAnotherIdea/enhancedcombathud-always-on-world-setting) to work.
Custom version of [dnd5e dark mode](https://github.com/JustAnotherIdea/dnd5edark-foundryvtt) suggested.
Compatible with [Dragon Flagon Manual Rolls](https://github.com/flamewave000/dragonflagon-fvtt/tree/master/df-manual-rolls).
